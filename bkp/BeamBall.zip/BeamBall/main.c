/**
 * Exemplo criado por Tiago Sanches
 */
#include <asf.h>
#include "string.h"

#define CONF_UART              UART0
#define CONF_UART_BAUDRATE     115200
#define CONF_UART_CHAR_LENGTH  US_MR_CHRL_8_BIT
#define CONF_UART_PARITY       US_MR_PAR_NO
#define CONF_UART_STOP_BITS    US_MR_NBSTOP_1_BIT

/** 
 * Defini��o dos pinos
 * Pinos do uC referente aos LEDS/ Bot�o
 *
 * O n�mero referente ao pino (PIOAxx), refere-se ao
 * bit que deve ser configurado no registrador para alterar
 * o estado desse bit espec�fico.
 *
 * exe : O pino PIOA_19 � configurado nos registradores pelo bit
 * 19. O registrador PIO_SODR configura se os pinos ser�o n�vel alto.
 * Nesse caso o bit 19 desse registrador � referente ao pino PIOA_19
 *
 * ----------------------------------
 * | BIT 19  | BIT 18  | ... |BIT 0 |
 * ----------------------------------
 * | PIOA_19 | PIOA_18 | ... |PIOA_0|
 * ----------------------------------
 */
#define PIN_LED_BLUE	19
#define PIN_LED_RED		20
#define PIN_LED_GREEN	20
#define PIN_BUTTON_1	3
#define PIN_BUTTON_2	12
#define time			100

/** 
 * Defini��o dos ports
 * Ports referentes a cada pino
 */
#define PORT_LED_BLUE	PIOA
#define PORT_LED_GREEN	PIOA
#define PORT_LED_RED	PIOC
#define PORT_BUT_1		PIOB
#define PORT_BUT_2		PIOC

/**
 * Define os IDs dos perif�ricos associados aos pinos
 */
#define ID_LED_BLUE		ID_PIOA
#define ID_LED_GREEN	ID_PIOA
#define ID_LED_RED		ID_PIOC
#define ID_BUT_1		ID_PIOB
#define ID_BUT_2		ID_PIOC

/**
 *	Define as masks utilziadas
 */
#define MASK_LED_BLUE	(1u << PIN_LED_BLUE)
#define MASK_LED_GREEN	(1u << PIN_LED_GREEN)
#define MASK_LED_RED	(1u << PIN_LED_RED)
#define MASK_BUT_1		(1u << PIN_BUTTON_1)
#define MASK_BUT_2		(1u << PIN_BUTTON_2)

int freq = 512;

void inicializacao_UART (){
	
		// cria a variavel serial para envio de dados
		// usando os valores definidos acima

		static usart_serial_options_t usart_options = {
			.baudrate = CONF_UART_BAUDRATE,
			.charlength = CONF_UART_CHAR_LENGTH,
			.paritytype = CONF_UART_PARITY,
			.stopbits = CONF_UART_STOP_BITS
		};
		
		// define a porta serial para a UART e com a variavel definida acima
		usart_serial_init(CONF_UART, &usart_options);

		// define a saida generica para ser o uart
		stdio_serial_init((Usart *)CONF_UART, &usart_options);
}

void tratamento_interrupcao_pioB(const uint32_t id, const uint32_t index)
{
	puts("\n\rEntrando - Interrupcao B\r");
	// seta a maxima frequencia permitida para 40Hz
	if (freq < 20480) {
		freq *= 2;
	}
	printf("%d",freq);
}

void tratamento_interrupcao_pioC(const uint32_t id, const uint32_t index)
{
	puts("\n\rEntrando - Interrupcao C\r");
	// set a mimima frequencia permitida para 0.03Hz
	if (freq > 15.36) {
		freq /= 2;
	}
	printf("%d",freq);
}

void configurar_botao1 (){
	puts("Configuracao botao 1\r");
	
	pio_set_input(PORT_BUT_1, MASK_BUT_1, PIO_PULLUP | PIO_DEBOUNCE);
	/* 
	*	Configura interrup��o para acontecer em borda de subida.
	*/
	// configura a porta do botao para lidar com interrupcao quando o estado volta para 1 (borda subindo)
	// indica tb qual funcao rodar na interrupcao
	pio_handler_set(PORT_BUT_1,ID_BUT_1,MASK_BUT_1,PIO_IT_RISE_EDGE,tratamento_interrupcao_pioB);

	/*
	*	Ativa interrup��o no perif�rico B porta do bot�o
	*/	
	// ativa a interrupcao na porta do botao 1 para mudancas na mascara do botao
	pio_enable_interrupt(PORT_BUT_1,MASK_BUT_1);
	
	/*
	*	Configura a prioridade da interrup��o no pORTB
	*/
	// define a prioridade de interrupcao do PIOB (o pio do botao)
	NVIC_SetPriority(PIOB_IRQn, 2 );
	
	/*
	*	Ativa interrup��o no port B
	*/
	NVIC_EnableIRQ(PIOB_IRQn);
}

void configurar_botao2 (){
	puts("Configuracao botao 2\r");
	
	pio_set_input(PORT_BUT_2, MASK_BUT_2, PIO_PULLUP | PIO_DEBOUNCE);
	/* 
	*	Configura interrup��o para acontecer em borda de subida.
	*/
	// configura a porta do botao para lidar com interrupcao quando o estado volta para 1 (borda subindo)
	// indica tb qual funcao rodar na interrupcao
	pio_handler_set(PORT_BUT_2,ID_BUT_2,MASK_BUT_2,PIO_IT_RISE_EDGE,tratamento_interrupcao_pioC);

	/*
	*	Ativa interrup��o no perif�rico B porta do bot�o
	*/	
	// ativa a interrupcao na porta do botao 1 para mudancas na mascara do botao
	pio_enable_interrupt(PORT_BUT_2,MASK_BUT_2);
	
	/*
	*	Configura a prioridade da interrup��o no pORTB
	*/
	// define a prioridade de interrupcao do PIOB (o pio do botao)
	NVIC_SetPriority(PIOC_IRQn, 2 );
	
	/*
	*	Ativa interrup��o no port B
	*/
	NVIC_EnableIRQ(PIOC_IRQn);
}

int main (void)
{
	/* Insert system clock initialization code here (sysclk_init()). */
	sysclk_init();
	board_init();

	inicializacao_UART();
	configurar_botao1();
	configurar_botao2();

	/**
	*	Configura sa�da
	*/
	pio_set_output(PORT_LED_BLUE  , MASK_LED_BLUE	,1,0,0);
	pio_set_output(PORT_LED_GREEN , MASK_LED_GREEN  ,1,0,0);

	while(1){

		pio_set(PIOA, (1 << PIN_LED_BLUE));
		pio_clear(PIOA, (1 << PIN_LED_GREEN));
		// atrasa a frequencia por uma variavel global freq
		delay_ms(freq);
		pio_clear(PIOA, (1 << PIN_LED_BLUE));
		pio_set(PIOA, (1 << PIN_LED_GREEN));
		delay_ms(freq);
		
	}
	
}
