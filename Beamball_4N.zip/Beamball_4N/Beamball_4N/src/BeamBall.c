/*
 * BeamBall.c
 *
 * Created: 08/11/2017 16:01:27
 *  Author: H243
 */
 
#include <asf.h>
#include "BeamBall.h"

void vReadSensor(void){

}

void vMalhaControle(double distance){

}

void vRunMotor(double pos){


}