/*
 * Config.c
 *
 * Created: 08/11/2017 16:02:02
 *  Author: H243
 */ 

 #include <asf.h>
 #include "BeamBall.h"

 void vConfigureUART(void) {
	 
	 // cria a variavel serial para envio de dados
	 // usando os valores definidos acima

	 static usart_serial_options_t usart_options = {
		 .baudrate = CONF_UART_BAUDRATE,
		 .charlength = CONF_UART_CHAR_LENGTH,
		 .paritytype = CONF_UART_PARITY,
		 .stopbits = CONF_UART_STOP_BITS
	 };
	 
	 // define a porta serial para a UART e com a variavel definida acima
	 usart_serial_init(CONF_UART, &usart_options);

	 // define a saida generica para ser o uart
	 stdio_serial_init((Usart *)CONF_UART, &usart_options);
 }

 
void vConfigurePWM(void){
	/* Disable the watchdog */
	WDT->WDT_MR = WDT_MR_WDDIS;

	/* Initialize the SAM system */
	//SystemInit();

	// disable the PIO (peripheral controls the pin)
	PIOA->PIO_PDR = PIO_PDR_P19;
	// select alternate function B (PWML0) for pin PA19
	PIOA->PIO_ABCDSR[0] |= PIO_ABCDSR_P19;
	PIOA->PIO_ABCDSR[1] &= ~PIO_ABCDSR_P19;
	// Enable the PWM peripheral from the Power Manger
	PMC->PMC_PCER0 = (1 << ID_PWM);
	// Select the Clock to run at the MCK (4MHz)
	PWM->PWM_CH_NUM[0].PWM_CMR = PWM_CMR_CPRE_MCK;
	// select the period 10msec
	PWM->PWM_CH_NUM[0].PWM_CPRD = 40000;
	// select the duty cycle
	PWM->PWM_CH_NUM[0].PWM_CDTY = 20000;
	// enable the channel
	PWM->PWM_ENA = PWM_ENA_CHID0;

	
	
}

void vPWMUpdateDuty(int duty){
	//VOU RECEBER INT ENTRE 0 - 9(MAX)
	float new_duty = (duty/100) * PWM->PWM_CH_NUM[0].PWM_CPRD; // PWM->PWM_CH_NUM[0].PWM_CPRD pegando o periodo da onda no registrador
	PWM->PWM_CH_NUM[0].PWM_CDTY = new_duty;
}

