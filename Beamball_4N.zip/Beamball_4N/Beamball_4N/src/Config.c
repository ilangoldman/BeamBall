/*
 * Config.c
 *
 * Created: 08/11/2017 16:02:02
 *  Author: H243
 */ 

 #include <asf.h>
 #include "BeamBall.h"

void vConfigurePWM(){
	pmc_enable_periph_clk(ID_PWM);
	pwm_channel_disable(PWM, PWM_CHANNEL);
	pwm_clock_t clock_setting = {
	.ul_clka = PWM_FREQUENCY * PERIOD_VALUE,
	.ul_clkb = 0,
	.ul_mck = sysclk_get_cpu_hz()
	};
	
	pwm_init(PWM, &clock_setting);
	
	/* Initialize PWM channel for LED0 */
	/* Period is left-aligned */
	pwm_channel.alignment = PWM_ALIGN_LEFT;
	/* Output waveform starts at a low level */
	pwm_channel.polarity = PWM_HIGH;
	/* Use PWM clock A as source clock */
	pwm_channel.ul_prescaler = PWM_CMR_CPRE_CLKA;
	/* Period value of output waveform */
	pwm_channel.ul_period = PERIOD_VALUE;
	/* Duty cycle value of output waveform */
	pwm_channel.ul_duty = MIN_DUTY_VALUE;
	pwm_channel.channel = PWM_CHANNEL;
	
	pwm_channel_init(PWM, &pwm_channel);
	
	
	//Descomente as linhas de baixo para colocar a interrupcao no PWM
	
	pwm_channel_enable_interrupt(PWM, PWM_CHANNEL, 0);
	
	NVIC_DisableIRQ(PWM_IRQn);
	NVIC_ClearPendingIRQ(PWM_IRQn);
	NVIC_SetPriority(PWM_IRQn, PWM_PRIORITY);
	NVIC_EnableIRQ(PWM_IRQn);
	
	
	pwm_channel_enable(PWM, PWM_CHANNEL);
	
}

void vPWMUpdateDuty(unsigned int duty){

}

void PWM_Handler(void){
	uint32_t events = pwm_channel_get_interrupt_status(PWM);
	gpio_toggle_pin(LED1_GPIO);
}