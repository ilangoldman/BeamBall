
#include <asf.h>
#include "BeamBall.h"

int main (void)
{
	sysclk_init();
	board_init();
	vConfigurePWM();
	//vConfigureButton();

	while(1){

	}
}
